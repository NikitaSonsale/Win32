#include<Windows.h>
#include<stdio.h>
#include "resource.h"
#include "project_groups.h"

#pragma comment(lib,"user32.lib")
#pragma comment(lib,"gdi32.lib")
#pragma comment(lib,"Kernel32.lib")

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
    static TCHAR szClassName[] = TEXT("project groups");

    static TCHAR szWindowCaption[] = TEXT("Group Names");

    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hButton_1 = NULL; 
    HWND hButton_2 = NULL;
    HWND hButton_3 = NULL;
    HWND hButton_4 = NULL;
    HWND hButton_5 = NULL;
    HWND hButton_6=  NULL;
    HWND hButton_7 = NULL;
    HWND hButton_8 = NULL;
    HWND hButton_9 = NULL;
    WNDCLASSEX wndEx;
    MSG msg;

    fopen_s(&g_file, "log.text","w");

    if(g_file == NULL)
    {
        MessageBox((HWND)NULL,TEXT("cannot create file"),TEXT("g_file"),MB_ICONERROR);
    }
    else
    {
        fprintf(g_file,"file created");
    }

    screen_width = GetSystemMetrics(SM_CXSCREEN);
    screen_height = GetSystemMetrics(SM_CYSCREEN);

    fprintf(g_file, "\nwindow_width:%d window_height:%d", screen_width, screen_height);

    ZeroMemory(&wndEx,sizeof(WNDCLASSEX));
    ZeroMemory(&msg,sizeof(MSG));

    hBrush =(HBRUSH)GetStockObject(WHITE_BRUSH);
    if(hBrush == NULL)
    {
        MessageBox((HWND)NULL,TEXT("Failed to acquire brush handle"),TEXT("GetStockObject"),MB_ICONERROR);
        return(EXIT_FAILURE);
    }

    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
    if(hCursor == NULL)
    {
        MessageBox((HWND)NULL,TEXT("Failed to acquire a handle to cursor"),TEXT("LoadCursor"),MB_ICONERROR);
        return(EXIT_FAILURE);       
    }
   
    hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON));
    if(hIcon==NULL)
    {
        MessageBox((HWND)NULL,TEXT("failed to load Icon"),TEXT("LoadIcon"),MB_ICONERROR);
        return(EXIT_FAILURE);
    }  

    hIconsm = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON));
    if(hIcon==NULL)
    {
        MessageBox((HWND)NULL,TEXT("failed to small load Icon"),TEXT("LoadIcon"),MB_ICONERROR);
        return(EXIT_FAILURE);
    }

    wndEx.cbSize = sizeof(WNDCLASSEX);
    wndEx.cbClsExtra = 0;
    wndEx.cbWndExtra = 0;
    wndEx.hbrBackground = hBrush;
    wndEx.hCursor = hCursor;
    wndEx.hIcon = hIcon;
    wndEx.hIconSm = hIconsm;
    wndEx.hInstance = hInstance;
    wndEx.lpszClassName = szClassName;
    wndEx.lpszMenuName = NULL;
    wndEx.lpfnWndProc = WndProc;
    wndEx.style = CS_HREDRAW |CS_VREDRAW;

    if(!RegisterClassEx(&wndEx))
    {
        MessageBox((HWND)NULL, TEXT("Failed to register window class"), TEXT("RegisterClassEx"), MB_ICONERROR); 
        return(EXIT_FAILURE);
    }

    registerDialogClass_1(hInstance);
    registerDialogClass_2(hInstance);
    registerDialogClass_3(hInstance);
    registerDialogClass_4(hInstance);
    registerDialogClass_5(hInstance);
    registerDialogClass_6(hInstance);
    registerDialogClass_7(hInstance);
    registerDialogClass_8(hInstance);
    registerDialogClass_9(hInstance);

    hWnd = CreateWindowEx(WS_EX_APPWINDOW,
                          szClassName,
                          szWindowCaption,
                          WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME,
                          0-10,
                          0,
                          screen_width + 20 ,
                          screen_height,
                          (HWND)NULL,
                          (HMENU)NULL,
                          hInstance,
                          NULL
                        );

    if(hWnd == NULL)
    {
        MessageBox((HWND)NULL,TEXT("Failed to create Window"),TEXT("CreatewindowEx"),MB_ICONERROR);
        return(EXIT_FAILURE);
    }


    hButton_1 = CreateWindow("BUTTON", "Dennis Ritchie", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                            3*screen_width/41, 31*screen_height/113, 150, 20, hWnd,(HMENU)BUTTON_1, hInstance, NULL);

    hButton_2 = CreateWindow("BUTTON", "Lady Ada Lovelace", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                            6.1*screen_width/13.6, 31*screen_height/113 , 150, 20, hWnd,(HMENU)BUTTON_2, hInstance, NULL);    
    
    hButton_3 = CreateWindow("BUTTON", "Linus Torvalds", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                            24.1*screen_width/30.3,  31*screen_height/113 , 150, 20, hWnd,(HMENU)BUTTON_3, hInstance, NULL);

    hButton_4 = CreateWindow("BUTTON", "Ken Thompson", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                            3*screen_width/41,  31*screen_height/54, 150, 20, hWnd,(HMENU)BUTTON_4, hInstance, NULL);

    hButton_5 = CreateWindow("BUTTON", "David Cutler", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                             6.1*screen_width/13.6,31*screen_height/54 , 150, 20, hWnd,(HMENU)BUTTON_5, hInstance, NULL);  
                              
    hButton_6 = CreateWindow("BUTTON", "Alan Turing", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                             24.1*screen_width/30.3, 31*screen_height/54, 150, 20, hWnd,(HMENU)BUTTON_6, hInstance, NULL); 

    hButton_7 = CreateWindow("BUTTON", "Donald Knuth", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                            3*screen_width/41, 31.2*screen_height/35.5 , 150, 20, hWnd,(HMENU)BUTTON_7, hInstance, NULL);

    hButton_8 = CreateWindow("BUTTON", "John Von Neumann", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                            6.1*screen_width/13.6, 31.2*screen_height/35.5 , 150, 20, hWnd,(HMENU)BUTTON_8, hInstance, NULL);

    hButton_9 = CreateWindow("BUTTON", "Helen Custer", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 
                            24.1*screen_width/30.3, 31.2*screen_height/35.5 , 150, 20, hWnd,(HMENU)BUTTON_9, hInstance, NULL);    
  

    if(hButton_1 == NULL)
    {
        MessageBox((HWND)NULL,TEXT("Failed to create button"),TEXT("CreateWindow"),MB_ICONERROR);
        return(EXIT_FAILURE);
    }

    AnimateWindow(hWnd,3000,AW_CENTER);
    //ShowWindow(hWnd,SW_MAXIMIZE);
    UpdateWindow(hWnd);

    while(GetMessage(&msg,NULL,0,0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg); 
    }
  
    return(msg.wParam);
}


void loadMyImage()
{
    hBitmapLogo = (HBITMAP)LoadImage(GetModuleHandle(NULL),"logo.bmp", 
                                  IMAGE_BITMAP,0, 0, LR_LOADFROMFILE);

    hBitmap = (HBITMAP)LoadImage(GetModuleHandle(NULL),"matrix-theme.bmp", 
                                  IMAGE_BITMAP, screen_width, screen_height, LR_LOADFROMFILE);

    hBitmap1 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"dennis_ritchie.bmp", 
                                  IMAGE_BITMAP,9*screen_width/64, 31*screen_height/128, LR_LOADFROMFILE); 

    hBitmap2 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"lady_ada_lovelace.bmp", 
                                  IMAGE_BITMAP, 9*screen_width/64, 31*screen_height/128, LR_LOADFROMFILE);
    
    hBitmap3 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"Linus-Torvalds.bmp", 
                                  IMAGE_BITMAP, 9*screen_width/64, 31*screen_height/128, LR_LOADFROMFILE);
    
    hBitmap4 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"ken-thompson.bmp", 
                                  IMAGE_BITMAP, 9*screen_width/64, 31*screen_height/128 , LR_LOADFROMFILE);
    
    hBitmap5 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"david_cutler.bmp", 
                                  IMAGE_BITMAP, 9*screen_width/64, 31*screen_height/128, LR_LOADFROMFILE);
    
    hBitmap6 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"alan_turing.bmp", 
                                  IMAGE_BITMAP, 9*screen_width/64, 31*screen_height/128, LR_LOADFROMFILE);
    
    hBitmap7 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"donald_knuth.bmp", 
                                  IMAGE_BITMAP, 9*screen_width/64, 31*screen_height/128, LR_LOADFROMFILE);
    
    hBitmap8 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"john_von_neumann.bmp", 
                                  IMAGE_BITMAP, 9*screen_width/64, 31*screen_height/128, LR_LOADFROMFILE);
    
    hBitmap9 = (HBITMAP)LoadImage(GetModuleHandle(NULL),"helen_custer.bmp", 
                                  IMAGE_BITMAP, 9*screen_width/64, 31*screen_height/128, LR_LOADFROMFILE);

}


LRESULT CALLBACK WndProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    HINSTANCE hInstance;
    int flag = 1; 
      
    switch(uMsg)
    {
        case WM_CREATE:
          
            loadMyImage();

            hImage = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                    0, 0, screen_width, screen_height, hWnd, NULL, GetModuleHandle(NULL),NULL);

            SendMessage(hImage,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap);

            hImage1 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                    screen_width/16, screen_height/65, 9*screen_width/64, 31*screen_height/128, hWnd, NULL, GetModuleHandle(NULL),NULL);

            SendMessage(hImage1,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap1);

         
            hImage2 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                    7*screen_width/16, screen_height/65, 9*screen_width/64, 31*screen_height/128, hWnd, NULL, GetModuleHandle(NULL),NULL);  

            SendMessage(hImage2,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap2);

            hImage3 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                    25*screen_width/32, screen_height/65, 9*screen_width/64, 31*screen_height/128, hWnd, NULL, GetModuleHandle(NULL),NULL);  

            SendMessage(hImage3,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap3);

            hImage4 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                   screen_width/16 ,31*screen_height/97 , 9*screen_width/64, 31*screen_height/128, hWnd, NULL, GetModuleHandle(NULL),NULL);  

            SendMessage(hImage4,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap4);

            hImage5 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                    7*screen_width/16, 31*screen_height/97, 9*screen_width/64, 31*screen_height/128 , hWnd, NULL, GetModuleHandle(NULL),NULL);  

            SendMessage(hImage5,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap5);

            hImage6 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                    25*screen_width/32 , 31*screen_height/97, 9*screen_width/64, 31*screen_height/128 , hWnd, NULL, GetModuleHandle(NULL),NULL);  

            SendMessage(hImage6,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap6);

            hImage7 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                  screen_width/16, 31*screen_height/50 ,9*screen_width/64, 31*screen_height/128, hWnd, NULL, GetModuleHandle(NULL),NULL);  

            SendMessage(hImage7,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap7);

            hImage8 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                   7*screen_width/16,  31*screen_height/50 , 9*screen_width/64, 31*screen_height/128, hWnd, NULL, GetModuleHandle(NULL),NULL);  

            SendMessage(hImage8,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap8);

            hImage9 = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                   25*screen_width/32, 31*screen_height/50 , 9*screen_width/64, 31*screen_height/128, hWnd, NULL, GetModuleHandle(NULL),NULL);  

            SendMessage(hImage9,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmap9);
   
            break;

        
        case WM_COMMAND:
            if (LOWORD(wParam) == BUTTON_1)
            {
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_1(hWnd);
                }
            }

            else if (LOWORD(wParam) == BUTTON_2)
            {
                flag = 1;
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_2(hWnd);
                }
            }

            else if (LOWORD(wParam) == BUTTON_3)
            {
                flag = 1;
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_3(hWnd);
                }
            }

            else if (LOWORD(wParam) == BUTTON_4)
            {
                flag = 1;
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_4(hWnd);
                }
            }
        
            else if (LOWORD(wParam) == BUTTON_5)
            {
                flag = 1;
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_5(hWnd);
                }
            }
        
            else if (LOWORD(wParam) == BUTTON_6)
            {
                flag = 1;
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_6(hWnd);
                }
            }
        
            else if (LOWORD(wParam) == BUTTON_7)
            {
                flag = 1;
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_7(hWnd);
                } 
            }
            
            else if (LOWORD(wParam) == BUTTON_8)
            {
                flag = 1;
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_8(hWnd);
                }
            }

            else if (LOWORD(wParam) == BUTTON_9)
            {
                flag = 1;
                if(flag == 1)
                {
                    flag = 0;
                    displayDialog_9(hWnd);
                }
            }
            break;

        case WM_DESTROY:
            if(g_file)
            {
                fprintf(g_file,"file close successfully");
                fclose(g_file);
                g_file = NULL;
            }
            PostQuitMessage(EXIT_SUCCESS);

            break;
    }
    return (DefWindowProc(hWnd,uMsg,wParam,lParam));
}

 
      
LRESULT CALLBACK MyDlgProc_1(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
      
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str[]=TEXT("C is quirky, flawed, and an enormous success.");
    switch(iMsg)
    {
        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;

        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));
		    DrawText(hdc,str,-1,&rc,DT_SINGLELINE|DT_CENTER|DT_VCENTER);
		    EndPaint(hwnd,&ps);
		    break;
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
}
   
LRESULT CALLBACK MyDlgProc_2(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
      
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str[]=TEXT("The more I study, the more insatiable do i feel my genius for it to be.");
    switch(iMsg)
    {
        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;

        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));
		    DrawText(hdc,str,-1,&rc,DT_SINGLELINE|DT_CENTER|DT_VCENTER);
		    EndPaint(hwnd,&ps);
		    break;
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
}

LRESULT CALLBACK MyDlgProc_3(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
      
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str[]=TEXT("Talk is cheap, show me the code.");
    switch(iMsg)
    {
        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;

        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));
		    DrawText(hdc,str,-1,&rc,DT_SINGLELINE|DT_CENTER|DT_VCENTER);
		    EndPaint(hwnd,&ps);
		    break;
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
}

LRESULT CALLBACK MyDlgProc_4(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
      
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str[]=TEXT("When in doubt, use brute force.");
    switch(iMsg)
    {
        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;

        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));
		    DrawText(hdc,str,-1,&rc,DT_SINGLELINE|DT_CENTER|DT_VCENTER);
		    EndPaint(hwnd,&ps);
		    break;
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
 }

LRESULT CALLBACK MyDlgProc_5(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
      
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str1[]=TEXT("It is impossible to acknowledge all the people who"); 
    TCHAR str2[] = TEXT("have contributed to the design of Windows NT.");
    TCHAR str3[] = TEXT("I must say that I did not design Windows NT I was");
    TCHAR str4[]  = TEXT("merely one of the contributors to design the system.");
    switch(iMsg)
    {
        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;


        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));

            SetTextAlign(hdc, TA_CENTER|TA_CENTER);
            TextOut(hdc, screen_width/2, screen_height/3, str1, lstrlen(str1));

            SetTextAlign(hdc, TA_TOP|TA_CENTER);
            TextOut(hdc, screen_width/2, screen_height/2.5, str2, lstrlen(str2));

            SetTextAlign(hdc, TA_TOP|TA_CENTER);
            TextOut(hdc, screen_width/2, screen_height/2.15, str3, lstrlen(str3));

            SetTextAlign(hdc, TA_TOP|TA_CENTER);
            TextOut(hdc, screen_width/2, screen_height/1.88, str4, lstrlen(str4));



           // SetTextAlign(hdc, TA_TOP|TA_CENTER);
            //TextOut(hdc, screen_width/, screen_height/2, str2, lstrlen(str));
            

          
          //  DrawText(hdc,str,-1,&rc,DT_WORDBREAK|DT_EDITCONTROL|DT_CENTER);
		    EndPaint(hwnd,&ps);
		    break;
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
}

LRESULT CALLBACK MyDlgProc_6(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
      
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str[]=TEXT("Mathematical reasoning may be regarded...");
    switch(iMsg)
    {
        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;

        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));
		    DrawText(hdc,str,-1,&rc,DT_SINGLELINE|DT_CENTER|DT_VCENTER);
		    EndPaint(hwnd,&ps);
		    break;
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
}

LRESULT CALLBACK MyDlgProc_7(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
      
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str[]=TEXT("If you optimize everything, \nyou will always be unhappy.");
    switch(iMsg)
    {
        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;

        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));
		    DrawText(hdc,str,-1,&rc,DT_SINGLELINE|DT_CENTER|DT_VCENTER);
		    EndPaint(hwnd,&ps);
		    break;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
}

LRESULT CALLBACK MyDlgProc_8(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str1[]=TEXT("If people do not believe that mathematics is simple,it is");
    TCHAR str2[] = TEXT("only because they do not \nrealize how complicated life is.");
    switch(iMsg)
    {
        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;

        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));

            SetTextAlign(hdc, TA_TOP|TA_CENTER);
            TextOut(hdc, screen_width/2, screen_height/3, str1, lstrlen(str1));

            SetTextAlign(hdc, TA_TOP|TA_CENTER);
            TextOut(hdc, screen_width/2, screen_height/2.5, str2, lstrlen(str2));

           // DrawText(hdc,str,-1,&rc,DT_SINGLELINE|DT_CENTER|DT_VCENTER);
		    EndPaint(hwnd,&ps);
		    break;
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
}

LRESULT CALLBACK MyDlgProc_9(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
      
    HDC hdc;
	PAINTSTRUCT ps;
	RECT rc;
	TCHAR str[]=TEXT("Her past is eclectic. She wrote 'Inside Windows NT',a popular 1992 Microsoft operating system guide,under her real name, and a novel, 'The Snake Handler's Daughter under her made-up one.");
    TCHAR str1[] = TEXT("Developed  By  MSTC");
    
    switch(iMsg)
    {
        case WM_CREATE:
           hLogo = CreateWindow("Static", " ", WS_TABSTOP | WS_VISIBLE | WS_CHILD |SS_BITMAP, 
                                   7*screen_width/22, 31*screen_height/120, 0, 0, hwnd, NULL, GetModuleHandle(NULL),NULL);

            SendMessage(hLogo,STM_SETIMAGE,(WPARAM) IMAGE_BITMAP,(LPARAM)hBitmapLogo);
        
           break;


        case WM_INITDIALOG:
            break;

        case WM_COMMAND:
            break;

        case WM_PAINT:
		    GetClientRect(hwnd,&rc);
		    hdc=BeginPaint(hwnd,&ps);
	        SetBkColor(hdc,RGB(0,0,0));
		    SetTextColor(hdc,RGB(0,255,0));
            SelectObject(hdc, CreateFont(50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Comic sans MS")));
		    DrawText(hdc,str,-1,&rc,DT_EDITCONTROL|DT_WORDBREAK|DT_CENTER);
            //EndPaint(hwnd,&ps);
        
            // hdc = BeginPaint(hwnd,&ps);
            // SetBkColor(hdc,RGB(0,0,0));
		    // SetTextColor(hdc,RGB(0,255,0));
            SetTextColor(hdc,RGB(255,165,0));
            SelectObject(hdc, CreateFont(35, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Elephant")));
            
            SetTextAlign(hdc, TA_TOP|TA_CENTER);
            TextOut(hdc, 6.1*screen_width/11.8,31*screen_height/40, str1, lstrlen(str1));
            
            EndPaint(hwnd,&ps);
		    break;
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
    }
    return DefWindowProc(hwnd,iMsg,wParam,lParam);    
}

void registerDialogClass_1(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush =(HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass1";
    wnd.lpfnWndProc = MyDlgProc_1;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
    RegisterClass(&wnd);
}

void registerDialogClass_2(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush =(HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass2";
    wnd.lpfnWndProc = MyDlgProc_2;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
   RegisterClass(&wnd);
}

void registerDialogClass_3(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush =(HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass3";
    wnd.lpfnWndProc = MyDlgProc_3;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
    RegisterClass(&wnd);
}

void registerDialogClass_4(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush =(HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass4";
    wnd.lpfnWndProc = MyDlgProc_4;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
    RegisterClass(&wnd);
}

void registerDialogClass_5(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush =(HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass5";
    wnd.lpfnWndProc = MyDlgProc_5;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
    RegisterClass(&wnd);
}

void registerDialogClass_6(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush = (HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass6";
    wnd.lpfnWndProc = MyDlgProc_6;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
    RegisterClass(&wnd);
}

void registerDialogClass_7(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush =(HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass7";
    wnd.lpfnWndProc = MyDlgProc_7;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
    RegisterClass(&wnd);
}

void registerDialogClass_8(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush =(HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass8";
    wnd.lpfnWndProc = MyDlgProc_8;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
    RegisterClass(&wnd);
}

void registerDialogClass_9(HINSTANCE hInst)
{
    HBRUSH hBrush = NULL;
    HCURSOR hCursor = NULL;
    HICON hIcon = NULL;
    HICON hIconsm = NULL;
    HWND hWnd = NULL;
    HWND hDlg =NULL;
    WNDCLASS wnd;
    MSG msg;

    ZeroMemory(&wnd,sizeof(WNDCLASS));
    ZeroMemory(&msg,sizeof(MSG));
    hBrush =(HBRUSH)GetStockObject(BLACK_BRUSH);
    hCursor =LoadCursor((HINSTANCE)NULL,IDC_ARROW);
   
    wnd.hbrBackground  = hBrush; 
    wnd.hCursor = hCursor;
    wnd.hInstance = hInst;
    wnd.lpszClassName = "myDialogClass9";
    wnd.lpfnWndProc = MyDlgProc_9;
    wnd.style = CS_HREDRAW |CS_VREDRAW;
    RegisterClass(&wnd);
}


void displayDialog_1(HWND hWnd)
{
    HBITMAP hBitmapLogo;
   CreateWindow("myDialogClass1", "Dennis Ritchie ", WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                 0, 0, screen_width, screen_height, hWnd, NULL, GetModuleHandle(NULL), NULL);
}

void displayDialog_2(HWND hWnd)
{
   CreateWindow("myDialogClass2", "Lady Ada Lovalace", WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                 0, 0, screen_width, screen_height, hWnd, NULL, GetModuleHandle(NULL), NULL);
}

void displayDialog_3(HWND hWnd)
{
   CreateWindow("myDialogClass3","Linus Torvalds",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                 0, 0, screen_width, screen_height,hWnd, NULL, GetModuleHandle(NULL), NULL);
}

void displayDialog_4(HWND hWnd)
{
   CreateWindow("myDialogClass4","Ken Thompson",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                0, 0, screen_width, screen_height,hWnd, NULL, GetModuleHandle(NULL), NULL);
}

void displayDialog_5(HWND hWnd)
{
   CreateWindow("myDialogClass5", "David Cutler", WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                0, 0, screen_width, screen_height, hWnd, NULL, GetModuleHandle(NULL), NULL);
}

void displayDialog_6(HWND hWnd)
{
   CreateWindow("myDialogClass6", "Alan Turing", WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                 0, 0, screen_width, screen_height, hWnd, NULL, GetModuleHandle(NULL), NULL);
}

void displayDialog_7(HWND hWnd)
{
   CreateWindow("myDialogClass7", "Donald Knuth", WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                0, 0, screen_width, screen_height,hWnd, NULL, GetModuleHandle(NULL),NULL);
}

void displayDialog_8(HWND hWnd)
{
   CreateWindow("myDialogClass8","Jon Von Neumann",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                0, 0, screen_width, screen_height,hWnd,NULL,GetModuleHandle(NULL),NULL);
}

void displayDialog_9(HWND hWnd)
{
   CreateWindow("myDialogClass9","Helen Custer",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
                0, 0, screen_width, screen_height, hWnd, NULL, GetModuleHandle(NULL), NULL);
}

 





