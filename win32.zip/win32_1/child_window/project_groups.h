#define BUTTON_1 5
#define BUTTON_2 6
#define BUTTON_3 7
#define BUTTON_4 8
#define BUTTON_5 9
#define BUTTON_6 11
#define BUTTON_7 12
#define BUTTON_8 13
#define BUTTON_9 15

FILE *g_file = NULL;
int client_width = 800;
int client_height = 800;
int screen_width;
int screen_height;
int window_width;
int window_height;
int window_x;
int window_y;

HBITMAP hBitmapLogo;
HBITMAP hBitmap;
HBITMAP hBitmap1;
HBITMAP hBitmap2;
HBITMAP hBitmap3;
HBITMAP hBitmap4;
HBITMAP hBitmap5;
HBITMAP hBitmap6;
HBITMAP hBitmap7;
HBITMAP hBitmap8;
HBITMAP hBitmap9;

HWND hLogo = NULL;
HWND hImage = NULL;
HWND hImage1 = NULL;
HWND hImage2 = NULL;
HWND hImage3 = NULL; 
HWND hImage4 = NULL;
HWND hImage5 = NULL;
HWND hImage6 = NULL;
HWND hImage7 = NULL;
HWND hImage8 = NULL;
HWND hImage9 = NULL;



LRESULT CALLBACK WndProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
void loadMyImage();

LRESULT CALLBACK MyDlgProc_1(HWND hDlg,UINT iMsg,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK MyDlgProc_2(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK MyDlgProc_3(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK MyDlgProc_4(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK MyDlgProc_5(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK MyDlgProc_6(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK MyDlgProc_7(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK MyDlgProc_8(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK MyDlgProc_9(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam);

void registerDialogClass_1(HINSTANCE hInstance);
void registerDialogClass_2(HINSTANCE hInstance);
void registerDialogClass_3(HINSTANCE hInstance);
void registerDialogClass_4(HINSTANCE hInstance);
void registerDialogClass_5(HINSTANCE hInstance);
void registerDialogClass_6(HINSTANCE hInstance);
void registerDialogClass_7(HINSTANCE hInstance);
void registerDialogClass_8(HINSTANCE hInstance);
void registerDialogClass_9(HINSTANCE hInstance);

void displayDialog_1(HWND hDlg);
void displayDialog_2(HWND hDlg);
void displayDialog_3(HWND hDlg);
void displayDialog_4(HWND hDlg);
void displayDialog_5(HWND hDlg);
void displayDialog_6(HWND hDlg);
void displayDialog_7(HWND hDlg);
void displayDialog_8(HWND hDlg);
void displayDialog_9(HWND hDlg);

