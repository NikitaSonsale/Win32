#include <Windows.h> 
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "kernel32.lib")

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam); 

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
    static TCHAR szClassName[] = TEXT("Harddisk"); 
    static TCHAR szWindowCaption[] = TEXT("My Application"); 

    HBRUSH hBrush = NULL; 
    HCURSOR hCursor = NULL; 
    HICON hIcon = NULL; 
    HICON hIconSm = NULL; 
    HWND hWnd = NULL; 

    WNDCLASSEX wndEx; 
    MSG msg; 

    ZeroMemory(&wndEx, sizeof(WNDCLASSEX)); 
    ZeroMemory(&msg, sizeof(MSG)); 

    hBrush = (HBRUSH)GetStockObject(WHITE_BRUSH); 
    if(hBrush == NULL)
    {
        MessageBox((HWND)NULL, TEXT("Could not obtain brush"), TEXT("GetStockObject"), MB_ICONERROR); 
        return (EXIT_FAILURE); 
    }

    hCursor = LoadCursor((HINSTANCE)NULL, IDC_ARROW); 
    if(hCursor == NULL)
    {
        MessageBox((HWND)NULL, TEXT("Could not obtain cursor"), TEXT("LoadCursor"), MB_ICONERROR); 
        return (EXIT_FAILURE); 
    }

    hIcon = LoadIcon((HINSTANCE)NULL, IDI_APPLICATION); 
    if(hIcon == NULL)
    {
        MessageBox((HWND)NULL, TEXT("Could not obtain icon"), TEXT("LoadIcon"), MB_ICONERROR);
        return (EXIT_FAILURE);  
    }

    hIconSm = LoadIcon((HINSTANCE)NULL, IDI_APPLICATION); 
    if(hIconSm == NULL)
    {
        MessageBox((HWND)NULL, TEXT("Could not obtain small icon"), TEXT("LoadIcon"), MB_ICONERROR); 
        return (EXIT_FAILURE); 
    }

    wndEx.cbSize = sizeof(WNDCLASSEX); 
    wndEx.cbClsExtra = 0; 
    wndEx.cbWndExtra = 0; 
    wndEx.hbrBackground = hBrush; 
    wndEx.hCursor = hCursor; 
    wndEx.hIcon = hIcon;
    wndEx.hIconSm = hIconSm; 
    wndEx.hInstance = hInstance; 
    wndEx.lpfnWndProc = WndProc; 
    wndEx.lpszClassName = szClassName; 
    wndEx.lpszMenuName = NULL; 
    wndEx.style = CS_HREDRAW | CS_VREDRAW; 

    if(!RegisterClassEx(&wndEx))
    {
        MessageBox((HWND)NULL, TEXT("Could not register window class"), TEXT("RegisterClassEx"), MB_ICONERROR); 
        return (EXIT_FAILURE); 
    }

    hWnd = CreateWindowEx(WS_EX_APPWINDOW, 
                            szClassName, 
                            szWindowCaption, 
                            WS_OVERLAPPEDWINDOW, 
                            CW_USEDEFAULT, 
                            CW_USEDEFAULT, 
                            CW_USEDEFAULT, 
                            CW_USEDEFAULT, 
                            (HWND)NULL, 
                            (HMENU)NULL, 
                            hInstance, 
                            NULL); 
    if(hWnd == NULL)
    {
        MessageBox((HWND)NULL, TEXT("Could not create application window"), TEXT("CreateWindowEx"), MB_ICONERROR); 
        return (EXIT_FAILURE); 
    }

    ShowWindow(hWnd, nShowCmd); 
    UpdateWindow(hWnd); 

    while(GetMessage(&msg, (HWND)NULL, 0, 0))
    {
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

    return (msg.wParam); 
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    static int cxClient, cyClient;
    HDC hdc = NULL;
    PAINTSTRUCT ps;
    int i;
    static HPEN hPen = NULL ;
    static HPEN hPen1 = NULL ;
    switch(uMsg)
    {
        case WM_CREATE: 
            hPen = CreatePen(PS_SOLID, 2, RGB(255, 0, 0)) ;
            hPen1 = CreatePen(PS_SOLID, 2, RGB(0, 0, 255)) ;  
            break;
        
        case WM_SIZE: 
            cxClient = LOWORD(lParam); 
            cyClient = HIWORD(lParam); 
            break; 

        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);

            //MoveToEx (hdc, 0, 0, NULL) ;
            Rectangle (hdc, cxClient / 8, cyClient / 8, 7 * cxClient / 8, 2 * cyClient / 8);
            MoveToEx (hdc, 5.3*cxClient/32, cyClient/8 , NULL);
            LineTo(hdc, 5.3*cxClient/32, 2*cyClient/8); 
            MoveToEx (hdc, 3.3*cxClient / 16, cyClient/8 , NULL);
            LineTo(hdc, 3.3*cxClient/16, 2*cyClient/8);
            MoveToEx (hdc, 3*cxClient / 8, cyClient/8 , NULL);
            LineTo(hdc, 3*cxClient/8, 2*cyClient/8); 

            SetTextAlign(hdc, TA_CENTER | TA_TOP); 
            TextOut(hdc, cxClient/2, cyClient/16, TEXT("Harddisk"), lstrlen("Harddisk"));

            SetTextAlign(hdc, TA_CENTER | TA_TOP); 
            TextOut(hdc, 9.3*cxClient/64, 4.7*cyClient/16, TEXT("Boot"), lstrlen("Boot"));

            SetTextAlign(hdc, TA_CENTER | TA_TOP); 
            TextOut(hdc, 9.3*cxClient/64, 5.1*cyClient/16, TEXT("Block"), lstrlen("Block"));

            SetTextAlign(hdc, TA_CENTER | TA_TOP); 
            TextOut(hdc,11.9*cxClient/64, 4.7*cyClient/16, TEXT("Super"), lstrlen("Super"));

            SetTextAlign(hdc, TA_CENTER | TA_TOP); 
            TextOut(hdc,11.9*cxClient/64, 5.1*cyClient/16, TEXT("Block"), lstrlen("Block"));

            SetTextAlign(hdc, TA_CENTER | TA_TOP); 
            TextOut(hdc, 9.3*cxClient/32, 4.7*cyClient/16, TEXT("DILBs"), lstrlen("DILBs"));

            SetTextAlign(hdc, TA_CENTER | TA_TOP); 
            TextOut(hdc, 5*cxClient/8, 4.7*cyClient/16, TEXT("Data Blocks"), lstrlen("Data Blocks"));          

            for(i = 0; i < 30; i = i + 3)
            {
                SelectObject(hdc,hPen);
                MoveToEx(hdc,((3.47+i/10.1)*cxClient/16), (1.1)*cyClient/8, NULL);
                LineTo(hdc,((3.47+i/10.1)*cxClient/16),(1.4)*cyClient/8);
            }

            for(i = 0; i < 30; i = i + 3)
            {
                SelectObject(hdc,hPen);
                MoveToEx(hdc,((3.47+i/10.0))*cxClient/16, 1.6*cyClient/8, NULL);
                LineTo(hdc,((3.47+i/10.0))*cxClient/16, 1.9*cyClient/8);
            }

            for(i = 0; i < 40; i = i + 2)
            {
                SelectObject(hdc,hPen1);
                Ellipse(hdc, ((3.04+i/10.1)*cxClient/8), (1.1)*cyClient/8, ((3.19+i/10.1)*cxClient/8), (1.4)*cyClient/8); 
            }

            for(i = 0; i < 40; i = i + 2)
            {
                SelectObject(hdc,hPen1);
                Ellipse(hdc, ((3.04+i/10.1)*cxClient/8), (1.6)*cyClient/8, ((3.19+i/10.1)*cxClient/8), (1.9)*cyClient/8);           
            }

            EndPaint (hWnd, &ps);
            hdc = NULL;
            break;

        case WM_DESTROY: 
            DeleteObject(hPen);
            DeleteObject(hPen1);
            PostQuitMessage(EXIT_SUCCESS); 
            break; 
    }

    return (DefWindowProc(hWnd, uMsg, wParam, lParam)); 
}
