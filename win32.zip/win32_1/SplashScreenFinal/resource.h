#define MY_BITMAP 101
#define MYICON 105


