#include<Windows.h>
#include"resource.h"

#pragma comment(lib,"user32.lib")
#pragma comment(lib,"gdi32.lib")
#pragma comment(lib,"Kernel32.lib")

//#define RADIO_BUTTON_1 5
#define RADIO_BUTTON_2 5
// #define RADIO_BUTTON_3 5
// #define RADIO_BUTTON_4 5
// #define RADIO_BUTTON_5 5

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

LRESULT CALLBACK P_WndProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK MyDlgProc(HWND, UINT, WPARAM, LPARAM);
void registerDialogClass(HINSTANCE hInstance);
void displayDialog(HWND hDlg);

LRESULT CALLBACK n_WndProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK n_MyDlgProc(HWND, UINT, WPARAM, LPARAM);
void n_registerDialogClass(HINSTANCE hInstance);
void n_displayDialog(HWND hDlg);

char name[50];

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int iCmdShow)
{
	WNDCLASSEX wndclass;
	TCHAR szAppName[] = TEXT("File System");
	HWND hwnd;
	// HWND hRadioButton1 = NULL;
    HWND hRadioButton2 = NULL;
    // HWND hRadioButton3 = NULL;
    // HWND hRadioButton4 = NULL;
    // HWND hRadioButton5 = NULL;
	MSG msg;

	wndclass.cbClsExtra = 0;
	wndclass.cbSize = sizeof(wndclass);
	wndclass.cbWndExtra = 0;
	//wndclass.hbrBackground = GetSysColorBrush(COLOR_GRADIENTACTIVECAPTION);
	wndclass.hbrBackground = CreateSolidBrush(RGB(79,0,39));               //(98,0,49), (79,0,39)
	//COLOR_GRADIENTACTIVECAPTION , COLOR_GRADIENTINACTIVECAPTION , COLOR_HIGHLIGHT
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hInstance = hInstance;
	wndclass.lpfnWndProc = WndProc;
	wndclass.lpszClassName = szAppName;
	wndclass.lpszMenuName = NULL;
	wndclass.style = CS_HREDRAW | CS_VREDRAW;

	if (!RegisterClassEx(&wndclass))
	{
		MessageBox(NULL, TEXT("Class Registration Failed"), TEXT("ERROR"), MB_OK | MB_ICONERROR);
		return 0;
	}

	// registerDialogClass(hInstance);
    // n_registerDialogClass(hInstance);

	hwnd = CreateWindow(szAppName, TEXT("FileSystem"), 
						WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 
						CW_USEDEFAULT, CW_USEDEFAULT, 
						CW_USEDEFAULT, NULL, 
						NULL, hInstance, 
						NULL);

	hRadioButton2 = CreateWindowEx(0,
                                   TEXT("BUTTON"),
                                   TEXT("Create File"),
                                   WS_CHILD | WS_VISIBLE | BS_RADIOBUTTON,
                                   25, 55, 130, 20,
                                   hwnd,
                                   HMENU(RADIO_BUTTON_2),
                                   hInstance,
                                   NULL
                                  );

	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return((int)msg.wParam);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    //static int cxClient, cyClient, cxChar, cyChar;
    HINSTANCE hInstance =  NULL;
    HDC hdc = NULL;

    TEXTMETRIC tm; 
    PAINTSTRUCT ps; 

    switch(uMsg)
    {
        case WM_COMMAND:
            if (LOWORD(wParam) == RADIO_BUTTON_2)
            {
                displayDialog(hWnd);
				DialogBox((HINSTANCE)GetWindowLongPtr(hWnd, GWLP_HINSTANCE), 
				          MAKEINTRESOURCE(FILESYSTEM), hWnd, (DLGPROC)MyDlgProc);
				
			}
            break;
        
		case WM_DESTROY:
            PostQuitMessage(EXIT_SUCCESS); 
            break; 
    }
	return (DefWindowProc(hWnd, uMsg, wParam, lParam)); 
}

void registerDialogClass(HINSTANCE hInst)
{
    WNDCLASSEX wndclass;
    TCHAR szAppName[] = TEXT("File System");
    HWND hwnd;
    MSG msg;

	ZeroMemory(&wndclass, sizeof(WNDCLASSEX));
    
    wndclass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wndclass.hCursor = LoadCursor(NULL, IDC_HAND);

    wndclass.hInstance = hInst;
    wndclass.lpszClassName = szAppName;
    wndclass.lpfnWndProc = P_WndProc;
    wndclass.style = CS_HREDRAW | CS_VREDRAW;
    RegisterClassEx(&wndclass);
}

LRESULT CALLBACK P_WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	switch (iMsg)
    {
    	case WM_CREATE:
        	break;
    	
		case WM_DESTROY:
        	PostQuitMessage(0);
        	break;
    }
    return(DefWindowProc(hwnd, iMsg, wParam, lParam));
}

BOOL CALLBACK MyDlgProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	static HBRUSH hBrush;
	int A[9] = {0};
	int reset;
	
	int wmId, wmEvent;
	int read_status, write_status;
	
	switch (iMsg)
	{
		case WM_INITDIALOG:
		//	EnableWindow(GetDlgItem(hwnd,ID_ETTEXT),false);
			EnableWindow(GetDlgItem(hwnd,RB_UR),false);
			EnableWindow(GetDlgItem(hwnd,RB_UW),false);
			EnableWindow(GetDlgItem(hwnd,RB_UX),false);
			EnableWindow(GetDlgItem(hwnd,RB_GR),false);
			EnableWindow(GetDlgItem(hwnd,RB_GW),false);
			EnableWindow(GetDlgItem(hwnd,RB_GX),false);
			EnableWindow(GetDlgItem(hwnd,RB_OR),false);
			EnableWindow(GetDlgItem(hwnd,RB_OW),false);
			EnableWindow(GetDlgItem(hwnd,RB_OX),false);
			EnableWindow(GetDlgItem(hwnd,RB_READ),false);
			EnableWindow(GetDlgItem(hwnd,RB_WRITE),false);

        	break;

		case WM_CTLCOLORDLG:
		case WM_CTLCOLORBTN:
		//case WM_CTLCOLOREDIT:
		case WM_CTLCOLORLISTBOX:
		case WM_CTLCOLORSTATIC:
		case WM_CTLCOLORMSGBOX:
			SetBkMode((HDC)wParam, RGB(255, 255, 255));
			SetTextColor((HDC)wParam, RGB(0, 0, 128));


			hBrush = CreateSolidBrush(RGB(200, 200, 200));
			return (INT_PTR)hBrush;
			break;

			switch (HIWORD(wParam))
			{
				case CTLCOLOR_DLG:
					return TRUE;

				case CTLCOLOR_EDIT:
					return TRUE;
			}

			break;
		// case WM_CREATE:
		// 	CheckDlgButton(hwnd, 1, BST_CHECKED);
		// 	break;


        case WM_COMMAND:
				// CheckDlgButton(hwnd, 1, BST_CHECKED);
				wmId = LOWORD(wParam);
        		wmEvent = HIWORD(wParam); 

				if(wmId == ID_ETFILENAME)
            	{
               		if(GetDlgItemText(hwnd, ID_ETFILENAME, name, 50)!='\0')
                	{
                		EnableWindow(GetDlgItem(hwnd,RB_READ),true);
                		EnableWindow(GetDlgItem(hwnd,RB_WRITE),true);
                	}
                	else
                	{
                      	if (IsDlgButtonChecked(hwnd, RB_READ)) 
                     		CheckDlgButton(hwnd,RB_READ, BST_UNCHECKED); 
				
						if (IsDlgButtonChecked(hwnd, RB_WRITE)) 
                   			CheckDlgButton(hwnd,RB_WRITE, BST_UNCHECKED); 
              	
				  		if (IsDlgButtonChecked(hwnd, RB_UR)) 
                   			CheckDlgButton(hwnd,RB_UR, BST_UNCHECKED); 
              			
						if (IsDlgButtonChecked(hwnd, RB_UW)) 
                   			CheckDlgButton(hwnd,RB_UW, BST_UNCHECKED); 
              			
						if (IsDlgButtonChecked(hwnd, RB_UX)) 
                   			CheckDlgButton(hwnd,RB_UX, BST_UNCHECKED); 

						if (IsDlgButtonChecked(hwnd, RB_GR)) 
                   			CheckDlgButton(hwnd,RB_GR, BST_UNCHECKED); 
              			
						if (IsDlgButtonChecked(hwnd, RB_GW)) 
                   			CheckDlgButton(hwnd,RB_GW, BST_UNCHECKED); 
              			
						if (IsDlgButtonChecked(hwnd, RB_GX)) 
                   			CheckDlgButton(hwnd,RB_GX, BST_UNCHECKED); 

						if (IsDlgButtonChecked(hwnd, RB_OR)) 
                   			CheckDlgButton(hwnd,RB_OR, BST_UNCHECKED); 
              			
						if (IsDlgButtonChecked(hwnd, RB_OW)) 
                   			CheckDlgButton(hwnd,RB_OW, BST_UNCHECKED); 
              			
						if (IsDlgButtonChecked(hwnd, RB_OX)) 
                   			CheckDlgButton(hwnd,RB_OX, BST_UNCHECKED); 
              		
						EnableWindow(GetDlgItem(hwnd,RB_READ),false);
                   		EnableWindow(GetDlgItem(hwnd,RB_WRITE),false); 
						EnableWindow(GetDlgItem(hwnd,RB_UR),false);
						EnableWindow(GetDlgItem(hwnd,RB_UW),false);
						EnableWindow(GetDlgItem(hwnd,RB_UX),false);
						EnableWindow(GetDlgItem(hwnd,RB_GR),false);
						EnableWindow(GetDlgItem(hwnd,RB_GW),false);
						EnableWindow(GetDlgItem(hwnd,RB_GX),false);
						EnableWindow(GetDlgItem(hwnd,RB_OR),false);
						EnableWindow(GetDlgItem(hwnd,RB_OW),false);
						EnableWindow(GetDlgItem(hwnd,RB_OX),false); 
                	}
				}

				if(wmId == RB_UR)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{
							A[0] = 1 ;
		            		MessageBoxA(hwnd, "Read permission is enabled for User!", "CheckBox", MB_OK);
						}
						else 
						{
							A[0] = 0 ;
		            		MessageBoxA(hwnd, "Read permission is disabled for User!", "CheckBox", MB_OK);
						}
					}
				}

				if(wmId == RB_UW)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{
							A[1] = 1 ;
		            		MessageBoxA(hwnd, "Write permission is enabled for User!", "CheckBox", MB_OK);
						}
						else 
						{
							A[1] = 0 ;
		            		MessageBoxA(hwnd, "Write permission is disabled for User!", "CheckBox", MB_OK);
						}
					}
       			}

				if(wmId == RB_UX)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{
							A[2] = 1 ;
		            		MessageBoxA(hwnd, "Execute permission is enabled for User!", "CheckBox", MB_OK);
						}
						else 
						{
							A[2] = 0 ;
		            		MessageBoxA(hwnd, "Execute permission is disabled for User!", "CheckBox", MB_OK);
						}
					}
       			}

				if(wmId == RB_GR)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{
							A[3] = 1 ;
		            		MessageBoxA(hwnd, "Read permission is enabled for Group!", "CheckBox", MB_OK);
						}
						else 
						{
							A[3] = 0 ;
		            		MessageBoxA(hwnd, "Read permission is disabled for Group!", "CheckBox", MB_OK);
						}
					}
       			}

				if(wmId == RB_GW)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{
							A[4] = 1 ;
		            		MessageBoxA(hwnd, "Write permission is enabled for Group!", "CheckBox", MB_OK);
						}
						else 
						{
							A[4] = 0 ;
		            		MessageBoxA(hwnd, "Write permission is disabled for Group!", "CheckBox", MB_OK);
						}
					}
       			}
				
				if(wmId == RB_GX)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{
							A[5] = 1 ;
		            		MessageBoxA(hwnd, "Execute permission is enabled for Group!", "CheckBox", MB_OK);
						}
						else 
						{
							A[5] = 0 ;
		            		MessageBoxA(hwnd, "Execute permission is disabled for Group!", "CheckBox", MB_OK);
						}
					}
       			}

				if(wmId == RB_OR)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{	
							A[6] = 1 ;
		            		MessageBoxA(hwnd, "Read permission is enabled for Other!", "CheckBox", MB_OK);
						}
						else 
						{
							A[6] = 0 ;
		            		MessageBoxA(hwnd, "Read permission is disabled for Other!", "CheckBox", MB_OK);
						}				
					}
       			}

				if(wmId == RB_OW)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{	
							A[7] = 1 ;
		            		MessageBoxA(hwnd, "Write permission is enabled for Others!", "CheckBox", MB_OK);
						}
						else 
						{
							A[7] = 0 ;
		            		MessageBoxA(hwnd, "Write permission is disabled for Others!", "CheckBox", MB_OK);
						}
					}
       			}

				if(wmId == RB_OX)
				{
					if (wmEvent == BN_CLICKED)
            		{
						int chkState = (int)SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
                		if (chkState == BST_CHECKED)
						{	
							A[8] = 1 ;
		            		MessageBoxA(hwnd, "Execute permission is enabled for Others!", "CheckBox", MB_OK);
						}
						else 
						{
							A[8] = 0 ;
		            		MessageBoxA(hwnd, "Execute permission is disabled for Others!", "CheckBox", MB_OK);
						}
					}
       			}

				if(wmId == RB_READ)
				{
					if(wmEvent == BN_CLICKED)
					{
						write_status = 0;
						read_status = 1;
						EnableWindow(GetDlgItem(hwnd,RB_UR), true);
						EnableWindow(GetDlgItem(hwnd,RB_UW), true);
						EnableWindow(GetDlgItem(hwnd,RB_UX), true);
						EnableWindow(GetDlgItem(hwnd,RB_GR), true);
						EnableWindow(GetDlgItem(hwnd,RB_GW), true);
						EnableWindow(GetDlgItem(hwnd,RB_GX), true);
						EnableWindow(GetDlgItem(hwnd,RB_OR), true);
						EnableWindow(GetDlgItem(hwnd,RB_OW), true);
						EnableWindow(GetDlgItem(hwnd,RB_OX), true);
						//EnableWindow(GetDlgItem(hwnd,ID_ETTEXT),false);
						MessageBox(NULL, "READ Clicked", TEXT("debug"), MB_OK);
					}
				}

				if(wmId == RB_WRITE)
				{
					if(wmEvent == BN_CLICKED)
					{
						read_status = 0;
						write_status = 1;
						EnableWindow(GetDlgItem(hwnd,RB_UR), true);
						EnableWindow(GetDlgItem(hwnd,RB_UW), true);
						EnableWindow(GetDlgItem(hwnd,RB_UX), true);
						EnableWindow(GetDlgItem(hwnd,RB_GR), true);
						EnableWindow(GetDlgItem(hwnd,RB_GW), true);
						EnableWindow(GetDlgItem(hwnd,RB_GX), true);
						EnableWindow(GetDlgItem(hwnd,RB_OR), true);
						EnableWindow(GetDlgItem(hwnd,RB_OW), true);
						EnableWindow(GetDlgItem(hwnd,RB_OX), true);
						//EnableWindow(GetDlgItem(hwnd,ID_ETTEXT),true);
						n_displayDialog(hwnd);
             			DialogBox((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), MAKEINTRESOURCE(NOTEPAD), hwnd, (DLGPROC)n_MyDlgProc);
						MessageBox(NULL, "WRITE Clicked", TEXT("debug"), MB_OK);
					}
				}

				switch (LOWORD(wParam))
				{
					case PB_CLOSE:
		  				EndDialog(hwnd, wParam);
						break;

        			case PB_OK:
         				GetDlgItemText(hwnd,ID_ETFILENAME,name,50);
         				MessageBox(NULL, name, TEXT("debug"), MB_OK);
        				//EndDialog(hwnd, wParam);
            			break; 

					// case RB_READ:
					// 	switch (HIWORD(wParam))
					// 	{
					// 		case BN_CLICKED: 
					// 			read_status =1;
					// 			//MessageBox(NULL, "READ Clicked", TEXT("debug"), MB_OK);
					// 			break;   		
					// 	}
					// 	break;
		
					// case RB_WRITE:
					// 	switch (HIWORD(wParam))
					// 	{
					// 		case BN_CLICKED: 
					// 			write_status =1;
					// 			//MessageBox(NULL,"write clicked", TEXT("debug"), MB_OK);
					// 			break;   		
					// 	}
					// 	break;

					case PB_RESET :
							for(int i = 0; i < 9; i++)
            				{
                				A[i] = 0;
            				}
							EnableWindow(GetDlgItem(hwnd,RB_UR),false);
							EnableWindow(GetDlgItem(hwnd,RB_UW),false);
							EnableWindow(GetDlgItem(hwnd,RB_UX),false);
							EnableWindow(GetDlgItem(hwnd,RB_GR),false);
							EnableWindow(GetDlgItem(hwnd,RB_GW),false);
							EnableWindow(GetDlgItem(hwnd,RB_GX),false);
							EnableWindow(GetDlgItem(hwnd,RB_OR),false);
							EnableWindow(GetDlgItem(hwnd,RB_OW),false);
							EnableWindow(GetDlgItem(hwnd,RB_OX),false);
							EnableWindow(GetDlgItem(hwnd,RB_READ),false);
							EnableWindow(GetDlgItem(hwnd,RB_WRITE),false);

            				switch(HIWORD(wParam))
        					{	 
            					case BN_CLICKED:        
               						SetDlgItemText(hwnd, ID_ETFILENAME,(""));
									//SetDlgItemText(hwnd, ID_ETTEXT,(""));

									BOOL checked = IsDlgButtonChecked(hwnd, RB_UR);
		   							if (checked) 
          							{
			  							CheckDlgButton(hwnd,RB_UR, BST_UNCHECKED); 
              						}
           						
									checked = IsDlgButtonChecked(hwnd, RB_UW);
           							if(checked) 
          							{ 
             							CheckDlgButton(hwnd,RB_UW, BST_UNCHECKED); 
              						}

           							checked = IsDlgButtonChecked(hwnd, RB_UX);
									if 	(checked) 
          							{
             							CheckDlgButton(hwnd,RB_UX, BST_UNCHECKED); 
              						}

           							checked = IsDlgButtonChecked(hwnd, RB_GR);
           							if (checked) 
          							{
              							CheckDlgButton(hwnd,RB_GR, BST_UNCHECKED); 
        							}

									checked = IsDlgButtonChecked(hwnd, RB_GW);
           							if (checked) 
          							{
             							CheckDlgButton(hwnd,RB_GW, BST_UNCHECKED); 
        							}
		
									checked = IsDlgButtonChecked(hwnd, RB_GX);
           							if (checked) 
          							{
			  							CheckDlgButton(hwnd,RB_GX, BST_UNCHECKED);
              						}

									checked = IsDlgButtonChecked(hwnd, RB_OR);
           							if (checked) 
          							{
            							CheckDlgButton(hwnd,RB_OR, BST_UNCHECKED); 
              						}

           							checked = IsDlgButtonChecked(hwnd, RB_OW);
           							if (checked) 
          							{
			  							CheckDlgButton(hwnd,RB_OW, BST_UNCHECKED); 
              						}

          							checked = IsDlgButtonChecked(hwnd, RB_OX);
           							if (checked) 
          							{
              							CheckDlgButton(hwnd,RB_OX, BST_UNCHECKED); 
              						}

            						checked = IsDlgButtonChecked(hwnd, RB_READ);
           							if (checked) 
          							{
										read_status = 0;
              							CheckDlgButton(hwnd,RB_READ, BST_UNCHECKED); 
              						}

           							checked = IsDlgButtonChecked(hwnd, RB_WRITE);
           							if (checked) 
          							{
										write_status = 0;
              							CheckDlgButton(hwnd,RB_WRITE, BST_UNCHECKED); 
            						}

                					MessageBox(NULL,"reset", TEXT("debug"), MB_OK);
               						break;
							}		      
        		}
				break;
	}
	return FALSE;
}

void displayDialog(HWND hWnd)
{
    CreateWindow("File System", TEXT("FileSystem"),  
	             WS_VISIBLE|WS_POPUP|WS_THICKFRAME, 
				 CW_USEDEFAULT, CW_USEDEFAULT, 
				 CW_USEDEFAULT, CW_USEDEFAULT, 
				 NULL, NULL, 
				 GetModuleHandle(NULL), NULL);
}


void n_registerDialogClass(HINSTANCE hInst)
{
    WNDCLASSEX wndclass;
    TCHAR szAppName[] = TEXT("EDIT BOX");
    HWND hwnd;
    MSG msg;

	ZeroMemory(&wndclass, sizeof(WNDCLASSEX));
    
    wndclass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wndclass.hCursor = LoadCursor(NULL, IDC_HAND);

    wndclass.hInstance = hInst;
    wndclass.lpszClassName = szAppName;
    wndclass.lpfnWndProc = n_WndProc;
    wndclass.style = CS_HREDRAW | CS_VREDRAW;
    RegisterClassEx(&wndclass);
}

LRESULT CALLBACK n_WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	switch (iMsg)
    {
    	case WM_CREATE:
    		break;
    
		case WM_DESTROY:
        	PostQuitMessage(0);
        	break;
    }
    return(DefWindowProc(hwnd, iMsg, wParam, lParam));
}

BOOL CALLBACK n_MyDlgProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{   
	TCHAR str[100];
	char str2[50];
	switch (iMsg)
    {
		// case WM_KEYDOWN:
		// 		if (wParam == VK_RETURN)
        // 		{
		// 			MessageBox(NULL,"reset", TEXT("debug"), MB_OK);
        //     		//SetCursorPos(0, 10);
  		// 		}
		// 		break;

    	case WM_INITDIALOG:
			EnableWindow(GetDlgItem(hwnd,ID_ETTEXT),true);
       		break;

      	case WM_COMMAND:
        	switch (LOWORD(wParam))
        	{
		   		case PB_2CLOSE:
            		//MessageBox(NULL, ("Do you want save changes to %s",name),TEXT("Notpad"),MB_OK);	

					wsprintf(str, "Do you want to save changes to your file named as %s", name);
					MessageBox(NULL,str,TEXT("Notpad"),MB_YESNOCANCEL);
                   // while(GetDlgItemText(hwnd,ID_ETTEXT,str2,50)!='\0');
					// MessageBox(NULL,str1,TEXT("Notpad"),MB_OK);
						
            		EndDialog(hwnd, wParam);
            		break;
			}
			break;		
	}
	
	return false;
}

void n_displayDialog(HWND hWnd)
{
    CreateWindow("EDIT BOX", TEXT("Edit box"),  
				WS_VISIBLE|WS_POPUP|WS_THICKFRAME, 
				CW_USEDEFAULT, CW_USEDEFAULT, 
				CW_USEDEFAULT, CW_USEDEFAULT, 
				NULL, NULL, 
				GetModuleHandle(NULL), NULL);
}