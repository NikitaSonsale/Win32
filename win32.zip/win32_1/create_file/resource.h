#pragma once
#define FILESYSTEM  	1

#define ID_ETFILENAME   2

#define RB_READ         3
#define RB_WRITE        4

#define RB_UR           5
#define RB_UW           6
#define RB_UX           7
#define RB_GR           8
#define RB_GW           9
#define RB_GX           10
#define RB_OR           11
#define RB_OW           12
#define RB_OX           13


#define PB_CLOSE	    14
#define PB_OK	        15
#define PB_RESET        16

#define NOTEPAD	        17

#define ID_ETTEXT       18
#define PB_2CLOSE	    20
#define PB_2OK	        19

